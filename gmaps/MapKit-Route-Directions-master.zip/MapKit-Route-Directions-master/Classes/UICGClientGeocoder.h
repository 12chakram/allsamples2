//
//  UICGClientGeocoder.h
//  MapDirections
//
//  Created by KISHIKAWA Katsumi on 09/08/12.
//  Copyright 2009 KISHIKAWA Katsumi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UICGClientGeocoder : NSObject {

}

@end
