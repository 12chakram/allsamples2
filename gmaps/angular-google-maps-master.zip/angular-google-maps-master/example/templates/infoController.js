function InfoController($scope) {
	$scope.templateValue = 'hello from the template itself';
};

