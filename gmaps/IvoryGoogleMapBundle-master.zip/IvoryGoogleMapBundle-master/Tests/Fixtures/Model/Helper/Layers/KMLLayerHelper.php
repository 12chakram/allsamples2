<?php

/*
 * This file is part of the Ivory Google Map package.
 *
 * (c) Eric GELOEN <geloen.eric@gmail.com>
 *
 * For the full copyright and license information, please read the LICENSE
 * file that was distributed with this source code.
 */

namespace Ivory\GoogleMapBundle\Tests\Fixtures\Model\Helper\Layers;

use Ivory\GoogleMap\Helper\Layers\KMLLayerHelper as BaseKMLLayerHelper;

/**
 * KML layer helper for testing.
 *
 * @author GeLo <geloen.eric@gmail.com>
 */
class KMLLayerHelper extends BaseKMLLayerHelper
{
}
