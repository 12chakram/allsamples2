# Google Map Layers

 1. [KML Layer](http://github.com/egeloen/IvoryGoogleMapBundle/blob/master/Resources/doc/usage/layers/kml_layer.md)
 2. Fusion Table Layer
 3. Traffic Layer
 4. Bicycling Layer
 5. Panorama Layer
